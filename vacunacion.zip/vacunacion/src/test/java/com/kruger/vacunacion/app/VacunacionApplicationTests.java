package com.kruger.vacunacion.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VacunacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
