package com.kruger.vacunacion.app.services;

import com.kruger.vacunacion.app.entities.TipoVacuna;
import org.springframework.stereotype.Service;


public interface TipoVacunaService  extends CommonService<TipoVacuna> {

}
