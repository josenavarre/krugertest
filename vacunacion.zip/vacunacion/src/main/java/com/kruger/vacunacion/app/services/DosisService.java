package com.kruger.vacunacion.app.services;

import com.kruger.vacunacion.app.entities.Dosis;
import org.springframework.stereotype.Service;



public interface DosisService extends CommonService<Dosis> {}
