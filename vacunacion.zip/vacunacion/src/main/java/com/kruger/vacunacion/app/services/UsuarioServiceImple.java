package com.kruger.vacunacion.app.services;

import com.kruger.vacunacion.app.entities.Usuario;
import org.springframework.stereotype.Service;

@Service
public class UsuarioServiceImple implements UsuarioService{
    @Override
    public Usuario DarDeAltaUsuario(String username, String password) {
        return null;
    }
}
